$(document).ready(function(){


	 /*La función .fadeOut()  hace desaparecer 
	 el elemento seleccionado con  la funcion jQuery "$".
	 El parámetro "slow" determina la velocidad en la cual ocurre 
	 la desaparición. */
	$("div").fadeOut("slow");

	/* La función .fadeIn() hace apaarecer el elemento seleccionado*/ 
   	$("div").fadeIn("slow");

});